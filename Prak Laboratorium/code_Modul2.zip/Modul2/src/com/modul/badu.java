package com.modul;

public class badu{

	public static void main (String[]args){
		Programmer badu = new Programmer("Badu");
		System.out.println("Nama : " + badu.tampilNama());
		badu.makan();
		badu.kerja();
		badu.santai();
	}
	
}
