package com.modul;

public class Syauqil {

	public static void main (String[]args){
		Programmer syauqi = new Programmer("Syauqil");
		System.out.println("Nama : " + syauqi.tampilNama());
		syauqi.makan();
		syauqi.kerja();
		syauqi.santai();
	}
	
}
