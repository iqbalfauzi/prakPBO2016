package com.modul;

public class Tentara extends Mahasiswa{

	public String pangkat;
	
	public Tentara(String n, String p){
		super(n, n);
		this.pangkat = p;
	}
	
	public String tampilkanPangkat(){
		return pangkat;
	}
	
	public void kerja1(){
		System.out.println("Dor.. Dor... Dor..");
	}
	
}
