package com.modul;

public class Programmer extends Mahasiswa{

	public Programmer(String n){
		super(n, n);
	}
	
	public void kerja(){
		System.out.println("Tak tak Klik");
	}
	
	public void santai(){
		System.out.println("Game over..");
	}
	
}
