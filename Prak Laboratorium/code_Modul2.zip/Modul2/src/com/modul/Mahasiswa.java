package com.modul;

public class Mahasiswa{
	
	public String nama;
	public String npm;
	public Mahasiswa (String nm, String npmX){
		this.nama = nm;
		this.npm = npmX;
	}
	public String tampilNpm(){
		return npm;
	}
	public String tampilNama(){
		return nama;
	}
	public void makan(){
		System.out.println("nyam...nyam...nyam...");
	}
	public void minum(){
		System.out.println("seegaaaarrrr....");
	}
	public void belajar(){
		System.out.println("Saya belajar");
	}
	public void olahRaga(){
		System.out.println("capeeeeekkkk\n");
	}
}


