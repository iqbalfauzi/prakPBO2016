package com.tugas;

public class main {

	public static void main (String[]args){
		PecintaAlam alam = new PecintaAlam("Syauqil", "09650122");
		System.out.println("Nama\t : " + alam.tampilNama());
		System.out.println("N I M\t : " + alam.tampilNpm());
		alam.memanjat();
		alam.lari();
		alam.makan();
		alam.minum();
		System.out.println();
		
		PecintaAlam aji = new PecintaAlam("Aji", "09650120");
		System.out.println("Nama\t : " + aji.tampilNama());
		System.out.println("N I M\t : " + aji.tampilNpm());
		aji.memanjat();
		aji.lari();
		aji.makan();
		aji.minum();
	}
	
}
