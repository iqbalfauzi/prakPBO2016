package com.tugas;

public class PecintaAlam extends Mahasiswa{
	
	public PecintaAlam(String nama, String npm){
		super(nama, npm);
	}
	
	public void memanjat(){
		System.out.println("Ayo memanjat mas...");
	}
	
	public void lari(){
		System.out.println("capeeeekkkk....");
	}
	
	
}
