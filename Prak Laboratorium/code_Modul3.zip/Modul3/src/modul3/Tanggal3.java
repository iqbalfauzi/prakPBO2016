/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package modul3;

/**
 *
 * @author pemrograman29
 */
public class Tanggal3 {

    public int getBulan() {
        return bulan;
    }

    public void setBulan(int bulan) {
        this.bulan = bulan;
    }

    public int getTahun() {
        return tahun;
    }

    public void setTahun(int tahun) {
        this.tahun = tahun;
    }

    public int getTanggal() {
        return tanggal;
    }

    public void setTanggal(int tanggal) {
        this.tanggal = tanggal;
    }

    private int tanggal;
    private int bulan;
    private int tahun;

    public Tanggal3() {
        tanggal = 0;
        bulan = 0;
        tahun = 0;
    }

    public Tanggal3(int tanggal) {
        this.tanggal = tanggal;
    }

    public Tanggal3(int tanggal, int bulan) {
        this.tanggal = tanggal;
        this.bulan = bulan;
    }

    public Tanggal3(int tanggal, int bulan, int tahun) {
        this.tanggal = tanggal;
        this.bulan = bulan;
        this.tahun = tahun;
    }

}
