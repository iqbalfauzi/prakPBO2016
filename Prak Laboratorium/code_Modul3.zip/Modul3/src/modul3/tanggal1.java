/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package modul3;

/**
 *
 * @author pemrograman29
 */
public class tanggal1 {

    private int tanggal;
    private int bulan;
    private int tahun;
    
    public tanggal1(int tanggal, int bulan, int tahun) {
        this.tanggal = tanggal;
        this.bulan = bulan;
        this.tahun = tahun;
    }

    public int getBulan() {
        return bulan;
    }

    public void setBulan(int bulan) {
        this.bulan = bulan;
    }

    public int getTahun() {
        return tahun;
    }

    public void setTahun(int tahun) {
        this.tahun = tahun;
    }

    public int getTanggal() {
        return tanggal;
    }

    public void setTanggal(int tanggal) {
        this.tanggal = tanggal;
    }

}
