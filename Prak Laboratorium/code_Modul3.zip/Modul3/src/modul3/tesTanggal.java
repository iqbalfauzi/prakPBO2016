/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package modul3;

/**
 *
 * @author pemrograman29
 */
public class tesTanggal {
    public static void main (String [] args){
        tanggal1 t = new tanggal1(1, 1, 2011);
        System.out.println(t.getTanggal());
        System.out.println(t.getBulan());
        System.out.println(t.getTahun());
        t.setTanggal(30);
        t.setBulan(3);
        t.setTahun(2011);
        System.out.println(t.getTanggal());
        System.out.println(t.getBulan());
        System.out.println(t.getTahun());

    }
}
