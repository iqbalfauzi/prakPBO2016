/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package modul3;

/**
 *
 * @author pemrograman29
 */
public class tesLagi {

    public static void main (String[]args){
        Tanggal3 t = new Tanggal3(1);
        System.out.println("Hari : " +t.getTanggal() + "\n");

        Tanggal3 t1 = new Tanggal3(2, 2);
        System.out.println("Hari : " +t1.getTanggal());
        System.out.println("Bulan : "+t1.getBulan() + "\n");

        Tanggal3 t2 = new Tanggal3(3, 3, 333);
        System.out.println("Hari : " +t2.getTanggal());
        System.out.println("Bulan : "+t2.getBulan());
        System.out.println("Tahun : " +t2.getTahun() + "\n");
    }

}
