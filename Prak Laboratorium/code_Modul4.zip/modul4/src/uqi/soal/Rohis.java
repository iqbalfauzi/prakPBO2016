/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package uqi.soal;

/**
 *
 * @author pemrograman29
 */
public class Rohis extends Mahasiswa{

    public Rohis(String nm, int um, String pk) {
        super(nm, um, pk);
    }

    @Override
    public void olahraga() {
        System.out.println("lari lari lari");

    }

    @Override
    public void kerja() {
        System.out.println("tik tak tok tok tok");

    }

}
