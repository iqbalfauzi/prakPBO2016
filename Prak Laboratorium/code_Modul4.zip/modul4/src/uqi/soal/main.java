/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uqi.soal;

/**
 *
 * @author pemrograman29
 */
public class main {

    public static void main(String[] args) {
        Mahasiswa orang1 = new Rohis("Syauqil", 21, "Programmer");
        System.out.println("Nama :" + orang1.tampilkanNama());
        System.out.println("Nama :" + orang1.tampilkanUmur());
        System.out.println("Nama :" + orang1.tampilkanPekerjaan());
        orang1.olahraga();
        orang1.kerja();
    }
}
