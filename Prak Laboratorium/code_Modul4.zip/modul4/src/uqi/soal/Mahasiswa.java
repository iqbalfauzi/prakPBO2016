package uqi.soal;

public class Mahasiswa {

    String nama;
    int umur;
    String pekerjaan;

    public Mahasiswa(String nm, int um, String pkj) {
        this.nama = nm;
        this.umur = um;
        this.pekerjaan = pkj;
    }

    public String tampilkanNama() {
        return nama;
    }

    public int tampilkanUmur() {
        return umur;
    }

    public String tampilkanPekerjaan() {
        return pekerjaan;
    }

    public void olahraga() {
        System.out.println("Jogging");
    }

    public void kerja() {
        System.out.println(" ");
    }
}
