package uqi.soal;

public class pekerja {

    public static void main(String args[]) {
        Mahasiswa[] profesi = new Mahasiswa[2];
        profesi[0] = new Rohis("Syauqil", 20, "Rohis");
        profesi[1] = new PencintaAlam("Aji", 34, "Pecinta Alam");

        for (int a = 0; a < 2; a++) {
            profesi[a].kerja();
            profesi[a].olahraga();
        }
    }
}
