package uqi.soal;

public class PencintaAlam extends Mahasiswa {

    public PencintaAlam(String nm, int um, String pk){
        super(nm, um, pk);
    }

    @Override
    public void olahraga() {
        System.out.println("olahraga");

    }

    @Override
    public void kerja() {
        System.out.println("naik naik");

    }

    public void tidur() {
        System.out.println("zzz...zzz");
    }

    public void mandi() {
        System.out.println("gubrak byuuur");
    }

    public void bermainGitar() {
        System.out.println("jreng...jreng");
    }

}
