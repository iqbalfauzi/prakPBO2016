package uqi.modul.baru;


public class sopir extends Manusia {
	

	public sopir(String nm, int um, String pkj) {
		super(nm, um, pkj);
		// TODO Auto-generated constructor stub
	}

	public void kerja(){
		System.out.println("NGuuuuuuuNGGGG");
	}

}
