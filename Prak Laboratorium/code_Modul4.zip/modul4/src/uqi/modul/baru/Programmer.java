/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package uqi.modul.baru;

/**
 *
 * @author pemrograman29
 */
public class Programmer extends Manusia{

    public Programmer(String nm4, int um4, String pkj4) {
        super(nm4, um4, pkj4);
    }

    @Override
    public void kerja() {
        System.out.println("tik tak tok");

    }

}
