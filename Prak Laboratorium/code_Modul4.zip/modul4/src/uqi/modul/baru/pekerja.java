package uqi.modul.baru;




public class pekerja {

	public static void main(String args []){
		Manusia [] profesi = new Manusia [3];
		profesi [0] = new Programmer("Syauqil", 20, "Programmer");
		profesi [1] = new tentara("Aji", 34, "Tentara");
		profesi [2] = new sopir("kamu", 24, "Sopir");
		
		for(int a=0; a<3; a++){
			profesi[a].kerja();
		}
		
	}
}
