package uqi.modul.baru;


public class Dedi {

	public static void main(String args []){
		Manusia orang1 = new sopir("Dedi", 21, "Sopir");
		System.out.println("Nama :"+orang1.tampilkanNama());
		System.out.println("Nama :"+orang1.tampilkanUmur());
		System.out.println("Nama :"+orang1.tampilkanPekerjaan());
		orang1.olahraga();
		orang1.kerja();
		
	}
}
