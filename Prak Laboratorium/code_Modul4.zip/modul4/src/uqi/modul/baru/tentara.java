package uqi.modul.baru;

public class tentara extends Manusia {

    public tentara(String nm3, int um3, String pkj3) {
        super(nm3, um3, pkj3);

    }

    @Override
    public void kerja() {
        System.out.println("dor...dor...dor...");

    }
}
