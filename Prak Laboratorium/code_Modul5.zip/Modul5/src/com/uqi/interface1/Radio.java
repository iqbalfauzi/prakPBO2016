/*
 * Copyleft @ 2011
 * Created By Muhammad Syauqil Ilmi
 * aksesgratis.blogspot.com
 */

package com.uqi.interface1;

/**
 *
 * @author syauqil
 */
public interface Radio {

    public void setGelombang(float gelombang);
    public void getGelombang();
    public void getSiaran();

}
