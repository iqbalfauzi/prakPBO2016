/*
 * Copyleft @ 2011
 * Created By Muhammad Syauqil Ilmi
 * aksesgratis.blogspot.com
 */

package com.uqi.interface1;

/**
 *
 * @author syauqil
 */
public class main {

    public static void main (String[]args){
        Radio r = new Compo();
        Tape t = new Compo();
        r.setGelombang(3);
        r.getGelombang();
        r.getSiaran();
        t.setPutarKaset("Dangdut");
        t.getKaset();
        t.getDengarKaset();
    }

}
