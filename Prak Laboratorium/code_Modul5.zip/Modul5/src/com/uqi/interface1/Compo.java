/*
 * Copyleft @ 2011
 * Created By Muhammad Syauqil Ilmi
 * aksesgratis.blogspot.com
 */

package com.uqi.interface1;

/**
 *
 * @author syauqil
 */
public class Compo implements Radio, Tape{

    float gelombang;
    String kaset;

    public void setGelombang(float  gelombang) {
        this.gelombang = gelombang;
    }

    public void getGelombang() {
        System.out.println("Sekarang berada pada gelombang "+ gelombang);
    }

    public void getSiaran() {
        System.out.println("Sekarang sedang siaran");
    }

    public void setPutarKaset(String kaset) {
        this.kaset = kaset;
    }

    public void getKaset() {
        System.out.println("Ambil kaset " + kaset);
    }

    public void getDengarKaset() {
        System.out.println("Lagi dengerin kaset " + kaset);
    }

}
