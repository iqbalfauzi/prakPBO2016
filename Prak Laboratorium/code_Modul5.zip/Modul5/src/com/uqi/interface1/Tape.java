/*
 * Copyleft @ 2011
 * Created By Muhammad Syauqil Ilmi
 * aksesgratis.blogspot.com
 */

package com.uqi.interface1;

/**
 *
 * @author syauqil
 */
public interface Tape {

    public void setPutarKaset(String kaset);
    public void getKaset();
    public void getDengarKaset();

}
