/*
 * Copyleft @ 2011
 * Created By Muhammad Syauqil Ilmi
 * aksesgratis.blogspot.com
 */
package com.uqi.abstract1;

/**
 *
 * @author syauqil
 */
public class main {

    public static void main(String[] args) {
        MusikTiup mt = new MusikTiup();
        mt.setNamaAlat("terompet");
        mt.setBunyi("toet-toet");
        mt.getInfo();
        System.out.println();
        MusikGesek mg = new MusikGesek();
        mg.setNamaAlat("biola");
        mg.setBunyi("ngik-ngok");
        mg.setJumDawai(4);
        mg.getInfo();
    }
}
