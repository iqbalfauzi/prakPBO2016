/*
 * Copyleft @ 2011
 * Created By Muhammad Syauqil Ilmi
 * aksesgratis.blogspot.com
 */

package com.uqi.abstract1;

/**
 *
 * @author syauqil
 */
public class MusikTiup extends AlatMusik {

    String bunyi;
    String NamaAlat;

    @Override
    public void setNamaAlat(String nama) {
        this.NamaAlat = nama;
    }

    @Override
    public void setBunyi(String bunyi) {
        this.bunyi = bunyi;
    }

    @Override
    public void getInfo() {
        System.out.println("Nama Alat Musik : " + NamaAlat);
        System.out.println("Bunyinya : " + bunyi);
    }

}
