/*
 * Copyleft @ 2011
 * Created By Muhammad Syauqil Ilmi
 * aksesgratis.blogspot.com
 */

package com.uqi.abstract1;

/**
 *
 * @author syauqil
 */
public class MusikGesek extends AlatMusik{

    String bunyi;
    String namaAlat;
    int jumDawai;

    @Override
    public void setNamaAlat(String nama) {
        this.namaAlat = nama;
    }

    @Override
    public void setBunyi(String bunyi) {
        this.bunyi = bunyi;
    }

    public void setJumDawai(int jumDawai) {
        this.jumDawai = jumDawai;
    }

    @Override
    public void getInfo() {
        System.out.println("Nama Alat Musik : " + namaAlat);
        System.out.println("Bunyinya : " + bunyi);
        System.out.println("Jumlah Dawai : "+ jumDawai); 
    }

}
