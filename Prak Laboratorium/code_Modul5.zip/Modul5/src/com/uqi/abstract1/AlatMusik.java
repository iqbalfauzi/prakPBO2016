/*
 * Copyleft @ 2011
 * Created By Muhammad Syauqil Ilmi
 * aksesgratis.blogspot.com
 */

package com.uqi.abstract1;

/**
 *
 * @author syauqil
 */
public abstract class AlatMusik {

    public abstract void setNamaAlat(String nama);
    public abstract void setBunyi(String bunyi);
    public abstract void getInfo();

}
