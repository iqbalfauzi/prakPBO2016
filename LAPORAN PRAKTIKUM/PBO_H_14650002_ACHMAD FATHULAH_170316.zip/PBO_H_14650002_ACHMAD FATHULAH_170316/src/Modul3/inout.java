/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul3;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author LAB_TI
 */
public class inout {
    public static void main(String[] args) {
        String judul = null, pemain = null, sutradara = null, publiser = null, kategori = null, topHits =null,penyanyi =null,produser =null;
        int stok = 0;
        String pilihan = null;
        String menu = null;
        //CdMusik musik = new CdMusik(judul, penyanyi, produser, publiser, topHits, kategori, stok, pilihan);
        //CdFilm film = new CdFilm(judul, pemain, sutradara, publiser, kategori, stok, pilihan);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        
        try {
            System.out.println("Pilih Kategori Berikut = "
                    + "\n1.Film"
                    + "\n2.Musik");
            menu = br.readLine();
            switch (menu) {
                case "1":
                    System.out.println("Judul = ");
                    judul = br.readLine();
                    System.out.println("Pemain = ");
                    pemain = br.readLine();
                    System.out.println("Sutradara = ");
                    sutradara = br.readLine();
                    System.out.println("Publisher = ");
                    publiser = br.readLine();
                    System.out.println("Pilih kategori berikut : "
                            + "\nSU"
                            + "\nD"
                            + "\nR"
                            + "\nA");
                    pilihan = br.readLine();
                    switch (pilihan) {
                        case "SU":
                            System.out.println("Kategori = Semua Umur");
                            break;
                        case "D":
                            System.out.println("Kategori = Dewasa");
                            break;
                        case "R":
                            System.out.println("Kategori = Remaja");
                            break;
                        case "A":
                            System.out.println("Kategori = Anak");
                            break;
                    }
                    System.out.println("Stok = ");
                    stok = Integer.parseInt(br.readLine());
                    CdFilm film = new CdFilm(judul, pemain, sutradara, publiser, kategori, stok);
                    System.out.println(film.toString());
                    break;
                case "2" :
                    System.out.println("Judul = ");
                    judul = br.readLine();
                    System.out.println("Penyanyi = ");
                    penyanyi = br.readLine();
                    System.out.println("Produser = ");
                    produser = br.readLine();
                    System.out.println("Publisher = ");
                    publiser = br.readLine();
                    System.out.println("Top Hits = ");
                    topHits = br.readLine();
                    System.out.println("Pilih kategori berikut : "
                            + "\nC"
                            + "\nJ"
                            + "\nP"
                            + "\nR"
                            + "\nO");
                    pilihan = br.readLine();
                    switch (pilihan) {
                        case "C":
                            System.out.println("Kategori = Classik");
                            break;
                        case "J":
                            System.out.println("Kategori = Jazz");
                            break;
                        case "P":
                            System.out.println("Kategori = Pop");
                            break;
                        case "R":
                            System.out.println("Kategori = Rock");
                            break;
                        case "O" :
                            System.out.println("Kategori = Other");
                    }
                    System.out.println("Stok = ");
                    stok = Integer.parseInt(br.readLine());
                    CdMusik musik = new CdMusik(judul, penyanyi, produser, publiser, topHits, kategori, stok);
                    System.out.println(musik.toString());
                    break;
            }
        }catch (Exception ex) {

        }
    }
}


