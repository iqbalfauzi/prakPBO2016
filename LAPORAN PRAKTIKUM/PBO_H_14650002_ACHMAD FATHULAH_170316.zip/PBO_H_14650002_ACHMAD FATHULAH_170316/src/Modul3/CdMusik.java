/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul3;

/**
 *
 * @author LAB_TI
 */
public class CdMusik extends rentalMaster{
    private String penyanyi;
    private String produser;
    private String topHits;
    

    CdMusik(String judul,String penyanyi,String produser, String publiser,String topHits, String kategori, int stok) {
        super(judul, publiser, kategori, stok);
        this.penyanyi = penyanyi;
        this.produser = produser;
        this.topHits = topHits;
    }

    
    public String toString(){
            return (super.toString()+"\nPenyanyi :"+penyanyi+"\nProduser : "+produser+"\ntop Hits : "+topHits);
            
        }
}
