/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul3;

/**
 *
 * @author LAB_TI
 */
public class orang {
    private String nama;
    private double tinggi;
    private double berat;
    public orang (String nama, double tinggi, double berat){
        this.nama = nama;
        this.tinggi = tinggi;
        this.berat = berat;
    }
    public String toString(){
        return ("Nama = "+nama+"\n Tinggi : "+tinggi+"\n Berat : "+berat );
        
    }
}
    class Pelajar extends orang{
        private String nim;
        private String asalSekolah;
        private double nilai;//RAnge : 0-30
        public Pelajar (String nama, double tinggi,double berat, String nim, String sekolah, double nilai){
            super(nama,tinggi,berat);
            this.nim = nim;
            asalSekolah = sekolah;
            this.nilai = nilai;
        }
        public String toString(){
            return (super.toString()+ "\nNIM :" +nim+"\nSekolah :"+asalSekolah+"\nNilai : "+nilai );
            
        }
        
    }
class Latihan2b{
    public static void main(String[] args) {
        Pelajar siswa = new Pelajar("Musa", 168, 62, "050107", "SMU Pancasila", 27.8);
        System.out.println(siswa.toString());
    }
}
