/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul3;

/**
 *
 * @author LAB_TI
 */
public class rentalMaster {
    private String judul;
    private String publiser;
    private String kategori;
    private int stok;
    public rentalMaster(String judul, String publiser, String kategori, int stok){
        this.judul = judul;
        this.publiser = publiser;
        this.kategori = kategori;
        this.stok = stok;
                 
    }
    public String toString(){
        return ("Judul = "+judul+"\n Publiser : "+publiser+"\n Kategori : "+kategori+"\nStok :"+stok );
        
    }
    
}
