    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */

    package pkg14650002;
    import java.io.*;
    import java.io.IOException;

    /**
     *
     * @author Achmad Fathullah
     */
    public class Main {

        /**
         * @param args the command line arguments
         */
        public static void main(String[] args) {
            String nama,nim,uts,uas,quiz,tgs,praktikum;
            int uas2,uts2,quiz2,tgs2,praktikum2;
            BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
            // TODO code application logic here
            try{
                System.out.println("+++++++++TUGAS 1++++++++");
                System.out.print("Silahkan masukkan nim anda :");
                nim = buff.readLine();
                System.out.print("Masukkan nama anda:");
                nama = buff.readLine();
                System.out.print("masukkan nilai uts anda:");
                uts = buff.readLine();
                uts2 = Integer.parseInt(uts);
                System.out.print("masukkan nilai uas anda:");
                uas = buff.readLine();
                uas2 = Integer.parseInt(uas);
                System.out.print("masukkan nilai quiz anda:");
                quiz = buff.readLine();
                quiz2 = Integer.parseInt(quiz);
                System.out.print("masukkan nilai tgs anda:");
                tgs = buff.readLine();
                tgs2 = Integer.parseInt(tgs);
                System.out.print("masukkan nilai praktikum anda:");
                praktikum = buff.readLine();
                praktikum2 = Integer.parseInt(uts);

                int nilai1 = (uts2 *25/100);
                int nilai2 = (uas2 *35/100);
                int nilai3 = (quiz2 *10/100);
                int nilai4 = (tgs2 *10/100);
                int nilai5 = (praktikum2 *20/100);
                int jumlah = (nilai1 + nilai2+ nilai3+nilai4+nilai5);
                String grade ="";
                if(jumlah>85){
                    grade = "A";
                }else if(jumlah>=70 && jumlah<=85){
                    grade = "B";
                }else if(jumlah>=50 && jumlah<=70){
                    grade = "C";
                }else{
                    grade = "D";
                }

                System.out.println("NILAI");
                System.out.println("Nilai uts"+nilai1);
                System.out.println("Nilai uas"+nilai2);
                System.out.println("Nilai quiz"+nilai3);
                System.out.println("Nilai tugas"+nilai4);
                System.out.println("Nilai praktikum"+nilai5);

                System.out.println("*******HASIL AKHIR*******");
                System.out.println("NAMA\t\t:"+nama);
                System.out.println("NIM\t\t:"+nim);
                System.out.println("Deskripsi nilai :"+"\t\n(UTS\t\t:"+uts2+"\t\nUAS\t\t:"+uas2+"\t\nQUIZ\t\t:"+quiz2+"\t\nTUGAS\t\t:"+tgs2+"\t\nPRAKTIKUM\t:"+praktikum2+")");
                System.out.println("Nilai Akhir\t:"+jumlah);
                System.out.println("Nilai Angka Anda>"+grade);

            }catch(IOException e){
                System.out.println("Error sam");
            }
        }

    }
