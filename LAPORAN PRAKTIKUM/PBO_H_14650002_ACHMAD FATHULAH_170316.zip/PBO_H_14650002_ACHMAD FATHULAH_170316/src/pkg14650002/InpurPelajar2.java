/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pkg14650002;

/**
 *
 * @author Achmad Fathullah
 */
public class InpurPelajar2 {
    public static void main(String[] args) {
        Pelajar b = new Pelajar();
        b.setNip(14650065);
        b.setNama("Toni");
        b.setNilai1(50);
        b.setNilai2(70);
        b.setTugas(50);
        b.cetak();
        b.isLulus();
    }
    
}
