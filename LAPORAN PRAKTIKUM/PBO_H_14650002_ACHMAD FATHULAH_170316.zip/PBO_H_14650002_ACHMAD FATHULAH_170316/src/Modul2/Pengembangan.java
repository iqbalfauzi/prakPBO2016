/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul2;
import java.io.*;
/**
 *
 * @author LAB_TI
 */
public class Pengembangan {
    private String nip,nama,alamat,tempat_lahir,jenis_kelamin,status;
    BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
    public String getNip() throws IOException{
        System.out.print("Silahkan masukkan nip anda :");
        nip = buff.readLine();
        return nip;
    }
    public String getNama() throws IOException{
        System.out.print("Silahkan masukkan nama anda :");
        nama = buff.readLine();
        
        return nama;
    }
    public String getAlamat() throws IOException{
        System.out.print("Silahkan masukkan alamat anda :");
        alamat = buff.readLine();
        return alamat;
    }
    public String getTempat() throws IOException{
        System.out.print("Silahkan masukkan tempat lahir anda anda :");
        tempat_lahir = buff.readLine();
        return tempat_lahir;
    }
    public String getJK() throws IOException{
        System.out.print("Silahkan masukkan jenis kelamin anda :");
        jenis_kelamin = buff.readLine();
        
        return jenis_kelamin;
    }
    public String getStatus() throws IOException{
        System.out.print("Silahkan masukkan status pernikahan  anda :");
        status = buff.readLine();
        
        return status;
    }
}
