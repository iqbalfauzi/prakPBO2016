/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul2;

/**
 *
 * @author LAB_TI
 */
public class Main {
    public static void main(String[] args) {
        Karyawan m = new Karyawan();
        m.setNama("Muhammad Faiz");
        m.setNip("13098786");
        System.out.println("Nama direktur\t:"+m.getNama()+"\nNIPnya adalah\t:"+m.getNip());
    }
    
}
