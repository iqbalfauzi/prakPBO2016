/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modul2;

import java.io.*;

/**
 *
 * @author Achmad Fathullah
 */
public class Menu {
    BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
    public void pilihan() throws IOException {
        PBO_H_14650002_AchmadFathullah_TugasKelas m = new PBO_H_14650002_AchmadFathullah_TugasKelas();
        for (;;) {
            System.out.println("Berikut ini adalah program tugas Kelas tentang Pembelian Obat");

            System.out.println("Pilih menu program berikut :\n" 
                    + "1. Pembayaran obat\n2. Exit program");
            String menu = buff.readLine();
            int a = Integer.parseInt(menu);
            if (a == 1) {
                System.out.println("=====Apotek UINMALIKI====="
                        +"\nKode Obat :\t"+m.getKode()
                        +"\nNama Obat :\t"+m.getNama()
                        +"\njenis obat :"
                        + m.getJenis()
                        +"\nKeterangan Obat :\t"+m.getKeterangan()
                        +"\nJumlah pembelian :\t"+m.getJumlah()
                        +"\nHarga Satuan :\t"+m.getSatuan()
                        +"\nDiskon obat :\t"+m.getDiskon()
                        +"\nHarga Total : Rp\t"+m.getTotal());;    
            } else if (a == 2) {
                break;
            }
            System.out.println("Apakah anda ingin lanjut :");
            String pilihan = buff.readLine();
            int choose = Integer.parseInt(pilihan);
            if(choose == 1 ){
                continue;
            }else{
                break;
            }
            
        }
    }
}
    

