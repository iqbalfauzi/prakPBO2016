/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Achmad Fathullah
 */
public class PBO_H_14650002_AchmadFathullah_TugasKelas {

    //Deklarasi Variable  
    private int jumlah, harga_satuan;
    private double diskon, harga_total;
    private String keterangan, nama, kode, jenis;

    //Fungsi input dari user lewat BufferedReader
    BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));

    public String getKode() throws IOException {
        System.out.print("Silahkan masukkan kode obat :");
        kode = buff.readLine();
        return kode;

    }

    public String getNama() throws IOException {
        System.out.print("Silahkan masukkan nama obat :");
        nama = buff.readLine();
        return nama;

    }

    public String getJenis() throws IOException {
        String jenis = " ";
        System.out.print("Silahkan masukkan jenis obat :"
                +"\n1. Umum \n2. Bebas Terjual \n3. Dengan Resep");
        String kode2 = buff.readLine();
        int kode = Integer.parseInt(kode2);
        if (kode == 1) {
            jenis = "Umum";

        } else if (kode == 2) {
            jenis = "Bebas Terjual ";
        } else {
            jenis = "Dengan Resep ";
        }

        return jenis;

    }

    public String getKeterangan() throws IOException {
        System.out.print("Silahkan masukkan keterangan obat :");
        keterangan = buff.readLine();
        return keterangan;

    }

    public int getJumlah() throws IOException {
        System.out.print("Silahkan masukkan jumlah obat :");
        String jumlah2 = buff.readLine();
        jumlah = Integer.parseInt(jumlah2);
        return jumlah;

    }

    public int getSatuan() throws IOException {
        System.out.print("Silahkan masukkan harga satuan obat :");
        String satuan = buff.readLine();
        harga_satuan = Integer.parseInt(satuan);
        return harga_satuan;

    }

    public double getDiskon() throws IOException {
        double diskon = 0;
        System.out.print("Silahkan masukkan diskon obat :"
                +"\n1. 1% \n2. 2% \n3. 3%" );
        String kode2 = buff.readLine();
        int menu = Integer.parseInt(kode2);
        if (menu == 1) {
            diskon = 0.001;
            System.out.println("1%");
        } else if (menu == 2) {
            diskon = 0.002;
            System.out.println("2%");
        } else {
            diskon = 0.003;
            System.out.println("3%");
        }

        return diskon ;

    }

    public double getTotal() {
        double hargafix = harga_satuan  * jumlah;
        double diskonfix = (double)harga_satuan * diskon;
        return  harga_total= (hargafix-diskonfix);
    }
    public static void main(String[] args) throws IOException {
      Menu m = new Menu();
      m.pilihan();
    }
}
