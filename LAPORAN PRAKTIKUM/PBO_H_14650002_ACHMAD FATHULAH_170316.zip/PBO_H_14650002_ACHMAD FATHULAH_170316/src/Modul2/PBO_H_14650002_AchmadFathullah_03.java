/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul2;

import java.io.IOException;

/**
 *
 * @author LAB_TI
 */
public class PBO_H_14650002_AchmadFathullah_03 {
    private String nip,nama,alamat,tempat_lahir,jenis_kelamin,status;
    public void setNip(String input){
        nip = input;
    }
    public void setNama(String input){
        nama = input;
    }
    public void setAlamat(String input){
        alamat = input;
    }
    public void setTempat(String input){
        tempat_lahir = input;
    }
    public void setJK(String input){
        jenis_kelamin = input;
    }
    public void setStatus(String input){
        status = input;
    }
    public String getNip(){
        return nip;
    }
    public String getNama(){
        return nama;
    }
    public String getAlamat(){
        return alamat;
    }
    public String getTempat(){
        return tempat_lahir;
    }
    public String getJK(){
        return jenis_kelamin;
    }
    public String getStatus(){
        return status;
    }
    public static void main(String[] args) throws IOException {
        PBO_H_14650002_AchmadFathullah_03 m = new PBO_H_14650002_AchmadFathullah_03();
        m.setNama("Achmad Fathullah");
        m.setNip("14650002");
        m.setAlamat("Jalan zaenal zakse Malang");
        m.setTempat("Malang");
        m.setJK("Laki laki");
        m.setStatus("Belum kawin");
        System.out.println("*****************Data Diri1*****************");
        System.out.println("Nama\t:"+ m.getNama()+"\nNIP:\t"+m.getNip()+"\nAlamat:\t"+m.getAlamat()+"\nTempat lahir:\t"+m.getTempat()+"\nStatus Pernikahan :\t"+m.getStatus());
        Pengembangan n = new Pengembangan();
        System.out.println("*****************Data Diri2*****************");
        System.out.println("Nama\t:"+ n.getNama()
                +"\nNIP\t\t:"+n.getNip()
                +"\nAlamat \t\t:"+n.getAlamat()
                +"\nTempat lahir\t\t:"+n.getTempat()
                +"\nStatus Pernikahan :\t"+n.getStatus());
        GajiPegawai o = new GajiPegawai();
        
        System.out.println("*****************Program Gaji Pegawai*****************");
        System.out.println(
                "---------------------------\nProgram Gaji Karyawan\n----------------------------"
                +"\nNIP\t\t:"+o.getNip()
                +"\nNama\t\t:"+ o.getNama()
                +"\nGolongan\t:"+o.getGolongan()
                +"\nGaji Pokok\t:"+o.getGajipokok()
                +"\nJumlah Jam \t:"+o.getJumlahjam()
                +"\nUpah Perjam \t:"+o.getUpah()
                +"\nTOTAL GAJI\t:"+o.getGaji());
        
    }
    
}
