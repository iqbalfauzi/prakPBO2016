/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul2;

/**
 *
 * @author LAB_TI
 */
public class Karyawan {
    private String nip;
    private String nama;
    
    public void setNip(String newValue){
            nip= newValue;
    }
    public void setNama(String newValue){
            nama= newValue;
    }
    public String getNip(){
        return nip;
    }
    public String getNama(){
        return nama;
    }
    
}
