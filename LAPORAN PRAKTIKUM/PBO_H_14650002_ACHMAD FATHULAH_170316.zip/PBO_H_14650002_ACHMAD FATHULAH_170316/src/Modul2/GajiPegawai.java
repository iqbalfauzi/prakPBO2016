/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modul2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author LAB_TI
 */
public class GajiPegawai {
    private String nip,golongan,nama;
    private int gajipokok,jumlahjam,upah,gaji;
    BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
    public String getNip() throws IOException{
        System.out.print("Silahkan masukkan nip anda :");
        nip = buff.readLine();
        return nip;
    }
    public String getNama() throws IOException{
        System.out.print("Silahkan masukkan nama anda :");
        nama = buff.readLine();
        
        return nama;
    }
    public String getGolongan() throws IOException{
        System.out.print("Silahkan masukkan golongan anda :");
        golongan = buff.readLine();
        return golongan;
    }
    public int getGajipokok() throws IOException{
        System.out.print("Silahkan masukkan gaji anda anda :");
         gajipokok = Integer.parseInt(buff.readLine());
        
        return gajipokok ;
    }
    public int getJumlahjam() throws IOException{
        System.out.print("Silahkan masukkan lama jam kerja anda anda :");
         jumlahjam = Integer.parseInt(buff.readLine());
        
        return jumlahjam ;
    }
    public int getUpah() throws IOException{
        System.out.print("Silahkan masukkan upah perjam  anda :");
        upah = Integer.parseInt(buff.readLine());
        
        return upah;
    }
    public int getGaji(){
        
        
        return gaji = gajipokok +(jumlahjam*upah);
    }
    
}
