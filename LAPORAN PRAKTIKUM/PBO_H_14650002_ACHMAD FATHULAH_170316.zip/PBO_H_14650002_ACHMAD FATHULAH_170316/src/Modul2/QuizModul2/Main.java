/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modul2.QuizModul2;

/**
 *
 * @author Achmad Fathullah
 */
public class Main {
    public static void main(String[] args) {
        for (;;) {
            try {
                Controller control = new Controller();
                control.menu();
            } catch (Exception e) {
                System.out.println("error");
            }
        }
    }
}

