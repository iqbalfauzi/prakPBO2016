/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modul2.QuizModul2;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author Achmad Fathullah
 */
public class Rumuz {
    BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
    private double alas, tinggi, a, b, t, jari, sisi, lsegitiga, ltabung, llingkaran, vtabung, vlingkaran, vkerucut, lpkerucut, lpkubus, lprismategak;
    private int pilih = 0;
    private String conf;
    
    Controller cn=new Controller();
    //Method untuk menghitung luas segitiga
    public double luassegitiga() {
        return lsegitiga = 0.5 * alas * tinggi;
    }
    //Method untuk menghitung luas trapesium
    public double luastrapesium() {
        return ltabung = 0.5 * (a + b) * t;
    }
    //Method untuk luas lingkaran
    public double luaslingkaran() {
        return llingkaran = Math.PI * jari * jari;
    }
    //Method untuk volume tabung
    public double volumetabung() {
        return vtabung = Math.PI * jari * jari * tinggi;
    }
    //Menghitung untuk volume limas segitiga
    public double volumelimassegitiga() {
        return vlingkaran = 0.3 * 0.5 * alas * tinggi;
    }
    //Menghitung volume kerucut
    public double volumekerucut() {
        return vkerucut = 0.3 * Math.PI * jari * jari * tinggi;
    }
    //Menghitung luas permukaan kerucut
    public double lpkerucut() {
        return lpkerucut = (Math.PI * jari * jari) + Math.PI * jari * tinggi;
    }
    //Menghitung luas permukaan kubus
    public double lpkubus() {
        return lpkubus = 6 * sisi * sisi;
    }
    //Menghitung luas permukaan prisma tegak
    public double lpprismategak() {
        return lprismategak = (2 * 0.5 * alas * tinggi) + (2 * 3 * alas);
    }
    //Method untuk memiih menu pada program
    public void setpilih(int pilih) {
        this.pilih = pilih;
        this.prosespilih();
    }
    //Mencetak menu hitung luas
    public void pilihluas() {
        System.out.println("Pilih Hitung Luas :");
        System.out.println("1. Segitiga");
        System.out.println("2. Srapesium");
        System.out.println("3. Lingkaran");
        System.out.print(">>>");
    }
    //Mencetak menu hitung volume
    public void pilihvolume() {
        System.out.println("Pilih Hitung Volume :");
        System.out.println("1. Tabung");
        System.out.println("2. Segitiga");
        System.out.println("3. Kerucut");
        System.out.print(">>>");
    }
    //Mencetak menu hitung luas permukaan
    public void pilihluaspermukaan() {
        System.out.println("Pilih Hitung Luas Permukaan :");
        System.out.println("1. kerucut");
        System.out.println("2. kubus");
        System.out.println("3. prisma tegak segitiga");
        System.out.println(">>>");
    }
    //Method untuk memproses method yang ada pada program
    public void prosespilih() {
            try {
                if (pilih == 1) {
                    this.pilihluas();
                    String hh = bf.readLine();
                    int choose = Integer.parseInt(hh);
                    switch (choose) {
                        case 1:
                            System.out.println("1.SEGITIGA");
                            System.out.print("\t\tAlas = ");
                            alas = Double.parseDouble(bf.readLine());
                            System.out.print("\t\tTinggi = ");
                            tinggi = Double.parseDouble(bf.readLine());
                            System.out.println("Luas segitiga = " + this.luassegitiga());
                            break;
                        case 2:
                            System.out.println("2. Trapesium");
                            System.out.print("\t\tAtas = ");
                            a = Double.parseDouble(bf.readLine());
                            System.out.print("\t\tBawah = ");
                            b = Double.parseDouble(bf.readLine());
                            System.out.print("\t\tTinggi = ");
                            t = Double.parseDouble(bf.readLine());
                            System.out.println("\t\tLuas SegiLima = " + this.luastrapesium());
                            break;
                        case 3:
                            System.out.println("2. Lingkaran");
                            System.out.print("\t\tJari-jari = ");
                            jari = Double.parseDouble(bf.readLine());
                            System.out.println("\t\tLuas Lingkaran = " + this.luaslingkaran());
                            break;
                        default:
                            System.out.println("Nomor yang anda masukkan tidak tersedia");
                    }
                } else if (pilih == 2) {
                    this.pilihvolume();
                    String hh = bf.readLine();
                    int choose = Integer.parseInt(hh);
                    switch (choose) {
                        case 1:
                            System.out.println("1.TABUNG");
                            System.out.print("\t\tjari = ");
                            jari = Double.parseDouble(bf.readLine());
                            System.out.print("\t\tTinggi = ");
                            tinggi = Double.parseDouble(bf.readLine());
                            System.out.println("Volume tabung = " + this.volumetabung());
                            break;
                        case 2:
                            System.out.println("2. LIMAS SEITIGA");
                            System.out.print("\t\tAtas = ");
                            alas = Double.parseDouble(bf.readLine());
                            System.out.print("\t\tTinggi = ");
                            tinggi = Double.parseDouble(bf.readLine());
                            System.out.println("\t\tVolume Limas segilima = " + this.volumelimassegitiga());
                            break;
                        case 3:
                            System.out.println("2. KERUCUT");
                            System.out.print("\t\tJari-jari = ");
                            jari = Double.parseDouble(bf.readLine());
                            System.out.print("\t\tJari-jari = ");
                            tinggi = Double.parseDouble(bf.readLine());
                            System.out.println("\t\tVolume Kerucut = " + this.volumekerucut());
                            break;
                        default:
                            System.out.println("Nomor yang anda masukkan tidak tersedia");
                    }
                } else if (pilih == 3) {
                    this.pilihluaspermukaan();
                    String hh = bf.readLine();
                    int choose = Integer.parseInt(hh);
                    switch (choose) {
                        case 1:
                            System.out.println("1.KERUCUT");
                            System.out.print("\t\tjari-jari = ");
                            jari = Double.parseDouble(bf.readLine());
                            System.out.print("\t\tTinggi = ");
                            tinggi = Double.parseDouble(bf.readLine());
                            System.out.println("Luas permukaan kerucut = " + this.lpkerucut());
                            break;
                        case 2:
                            System.out.println("2. KUBUS");
                            System.out.print("\t\tsisi = ");
                            sisi = Double.parseDouble(bf.readLine());
                            System.out.println("\t\tLuas Permukaan kubus = " + this.lpkubus());
                            break;
                        case 3:
                            System.out.println("2. PRISMA TEGAK SEGITIGA");
                            System.out.print("\t\talas = ");
                            alas = Double.parseDouble(bf.readLine());
                            System.out.print("\t\tinggi = ");
                            tinggi = Double.parseDouble(bf.readLine());
                            System.out.println("\t\tLuas Prisma tegak = " + this.lpprismategak());
                            break;
                        default:
                            System.out.println("Nomor yang anda masukkan tidak tersedia");
                    }
                }else if(pilih==4){
                        System.exit(0);
                }
            } catch (Exception e) {
                System.out.println("Error" + e);
            }
    }
}
