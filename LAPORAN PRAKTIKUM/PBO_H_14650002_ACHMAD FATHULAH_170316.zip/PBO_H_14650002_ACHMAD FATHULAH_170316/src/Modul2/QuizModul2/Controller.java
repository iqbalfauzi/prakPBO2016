/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modul2.QuizModul2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Achmad Fathullah
 */
public class Controller {
    public void menu() throws IOException {
        try {
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("=======================");
            System.out.println("Berikut program Perhitungan Bangung");
            System.out.println("Silahkan pilih menu :");
            System.out.println("1. Hitung Luas");
            System.out.println("2. Hitung Volume");
            System.out.println("3. Hitung Luas Permukaan");
            System.out.println("4. Keluar");
            System.out.println("Pilih Nomor");
            int pilih = Integer.parseInt(bf.readLine());
            System.out.println("=======================");

            Rumuz c = new Rumuz();
            c.setpilih(pilih);
        } catch (Exception e) {
            System.out.println("error");
        }
    }
}

