/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
import javax.swing.*;
public class CobaInput2 {
    public static void main(String[] args) {
        String nama,kota;
        nama = JOptionPane.showInputDialog("Nama anda :");
        kota = JOptionPane.showInputDialog("Kota asal :");
        System.out.println("Selamat datang " + nama + "Dari  "+ kota);
        System.out.println("Selamat datang "+ nama + "Dari "+ kota);
        System.exit(0);
    }
}
