/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
public class ClassInstances {
    public static void main(String[] args) {
        Ship s1 = new Ship();
        s1.x = 0.0;
        s1.y = 0.0;
        s1.speed =1.0;
        s1.direction = 0.0;
        s1.name = "Ship1";
        Ship s2 = new Ship();
    }
    
}
