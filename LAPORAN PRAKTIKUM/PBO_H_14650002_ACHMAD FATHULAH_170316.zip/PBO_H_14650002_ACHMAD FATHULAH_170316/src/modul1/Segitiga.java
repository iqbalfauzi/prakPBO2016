/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
public class Segitiga {
    private int alas,tinggi;
    public void isiField(int x,int y){
        alas = x;
        tinggi = y;
    }
    public int tampilAlas(){
        return alas;
    }
    public int tampilTinggi(){
        return tinggi;
    }
    public double HitungLuas(){
        return 0.5 * (double)(alas*tinggi);
    }
}
