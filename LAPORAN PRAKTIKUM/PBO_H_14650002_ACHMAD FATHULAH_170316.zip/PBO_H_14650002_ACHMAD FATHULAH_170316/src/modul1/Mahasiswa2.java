/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
import java.io.*;
public class Mahasiswa2 {
    public static void main(String[] args) throws IOException{
        penilaian objek = new penilaian();
//        objek.getNama();
//        objek.getNip();
//        objek.getTugas();
//        objek.getUts();
//        objek.getUas();
//        objek.nilaiAkhir();
        
        
        System.out.println("Data santri anwarul huda"); 
        System.out.println("Data Pelajar : "+objek.getNama());
        System.out.println("NIP : "+objek.getNip());
        System.out.println("Nilai uts : "+objek.getUts());
        System.out.println("Nilai tugas : "+objek.getTugas());
        System.out.println("Nilai tgs : "+objek.getTugas());
        System.out.println("Nilai Akhir anda : "+objek.nilaiAkhir());
        System.out.println("Status : "+objek.CekLulus());
            
    }
    
}
