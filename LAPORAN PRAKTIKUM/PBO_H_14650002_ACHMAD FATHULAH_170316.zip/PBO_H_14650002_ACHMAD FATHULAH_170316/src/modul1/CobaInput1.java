/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
import java.io.*;
public class CobaInput1 {
    public static void main(String[] args) throws IOException {
       BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
       String nama,kota;
        System.out.print("Nama anda :");
        nama = br.readLine();
        System.out.print("Kota Asal :");
        kota  = br.readLine();
        System.out.println("Selamat datang "+nama+"Dari :"+kota);
        
    }
}
