/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
public class Ship {
    public double x,y,speed,direction;
    public String name;
    public void setx(double x){
        this.x = x;
        
    }
    public double x(){
        return x;
    }
    public void sety(double y){
        this.y = y;
        
    }
    public double y(){
        return y;
    }
    public void setSpeed(double speed){
        this.speed = speed;
    }
    public double speed(){
        return speed;
    }
    public void setdirection(double direction){
        this.direction = direction;
    }
    public double direction(){
        return direction;
    }
    public void setname(String name){
        this.name = name;
        
    }
    public String name(){
        return name;
    }
}
