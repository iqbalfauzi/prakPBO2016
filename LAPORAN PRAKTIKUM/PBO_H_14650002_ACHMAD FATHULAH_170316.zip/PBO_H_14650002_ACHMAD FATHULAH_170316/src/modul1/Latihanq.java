/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
public class Latihanq {
    public static void main(String[] args) {
        Segitiga SN = new Segitiga();
        SN.isiField(4, 6);
        System.out.println("Panjang alas segitiga adalah"+SN.tampilAlas());
        System.out.println("Panjang tinggi segitiga adalah"+SN.tampilTinggi());
        System.out.println("Luas Segitga adalah "+SN.HitungLuas());
        Segitiga St = new Segitiga();
        St.isiField(3, 5);
        System.out.println("Panjang alas segitiga adalah"+St.tampilAlas());
        System.out.println("Panjang tinggi segitiga adalah"+St.tampilTinggi());
        System.out.println("Luas Segitga adalah "+St.HitungLuas());
        
    }
    
}
