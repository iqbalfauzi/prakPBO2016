/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
public class InputPelajar1 {
     public static void main(String[] args) {
        Pelajar b = new Pelajar();
        b.setNip(050123);
        b.setNama("Budiono");
        b.setNilai1(55.9);
        b.setNilai2(65.8);
        b.setTugas(72);
        b.cetak();
        b.isLulus();
    }
    
}
