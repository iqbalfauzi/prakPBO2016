/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
public class Student {
String name;
double test1,test2,test3;
double getAverage(){
    return (test1 + test2 + test3)/3;
    
}
double getsum(){
    return (test1+test2+test3);
}
}
