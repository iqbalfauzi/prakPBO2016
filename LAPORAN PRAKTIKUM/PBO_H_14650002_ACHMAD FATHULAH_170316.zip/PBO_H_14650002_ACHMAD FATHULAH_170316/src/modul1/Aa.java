/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;


import java.io.*;
/**
 *
 * @author Achmad Fathullah
 */
public class Aa {
    public static void main(String[] args) throws IOException{
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        Student std = new Student();
        System.out.println("Nama anda :");
        std.name = input.readLine();
        System.out.println("Masukkan nilai 1 :");
        std.test1 = Double.parseDouble(input.readLine());
        System.out.println("Masukkan nilai 2 :");
        std.test2 = Double.parseDouble(input.readLine());
        System.out.println("Masukkan nilai 3 :");
        std.test3 = Double.parseDouble(input.readLine());
        System.out.println("Hello " + std.name+ "Your grades are:");
        //System.out.println(std.name);
        System.out.println(std.test1);
        System.out.println(std.test2);
        System.out.println(std.test3);
        System.out.println("Your average is : " + std.getAverage());
        System.out.println("Your sum is : " + std.getsum());
        System.out.println("*************************************");
    }
    
}
