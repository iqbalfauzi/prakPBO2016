/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
import java.io.*;
public class penilaian {
         double nilaiakhir,tugas,uts,uas;
         int nim;
         String nama;
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
    
    public String getNama() throws IOException{
        System.out.println("Masukkan nama :");
        return nama = input.readLine();
    }
    
    public int getNip() throws IOException{
        System.out.println("Masukkan nim anda :");
        return nim = Integer.parseInt(input.readLine());
    }
    
    public double getTugas() throws IOException{
        System.out.println("Masukkan nilai tugas :");
        return  tugas = Double.parseDouble(input.readLine());
    }
    
    public double getUas() throws IOException{
        System.out.println("Masukkan nilai uas :");
        return  uas = Double.parseDouble(input.readLine());
    }
         
    public double getUts() throws IOException{
        System.out.println("Masukkan nilai uts anda :");
        
        return  uts = Double.parseDouble(input.readLine());
    }
    
    public double nilaiAkhir(){
        return  nilaiakhir =0.35 * (tugas)+ 0.40 *(uts)+0.25*(uas);
    }
    public String CekLulus(){
     String grade ="";
     
                if(nilaiakhir>60){
                    return grade = "LULUS";
             
                }else{
                   return grade = "Tidak Lulus";
                }
    } 
//    public void cetak(){
//        //System.out.println(HitungNA());
//        
//        System.out.println("Data Pelajar : "+getNama());
//        System.out.println("NIP : "+getNip());
//        System.out.println("Nilai 1 : "+getNilai1());
//        System.out.println("Nilai 2 : "+getNilai2());
//        System.out.println("Nilai tgs : "+getTugas());
//        System.out.println("Nilai Akhir anda : "+HitungNA());
//        System.out.println("Status : "+isLulus());
//        
//        
//        
//    }
   
}

