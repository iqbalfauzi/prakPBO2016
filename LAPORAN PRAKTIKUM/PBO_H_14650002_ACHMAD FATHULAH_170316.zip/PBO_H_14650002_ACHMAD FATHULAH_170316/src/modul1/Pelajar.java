/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;



/**
 *
 * @author Achmad Fathullah
 */
public class Pelajar {
    
         
         double nilaiakhir,nilaiUjian1,nilaiUjian2,nilaiTugas;
         int nip;
         String nama;
    public void setNama(String nama){
        this.nama = nama;
    }
    public String getNama(){
        return nama;
    }
         public void setNip(double nip){
        this.nip = (int) nip;
    }
    public int getNip(){
        return nip;
    }
         public void setNilai1(double nilaiUjian1){
        this.nilaiUjian1  =nilaiUjian1 ;
    }
    public double getNilai1(){
        return  nilaiUjian1;
    }
         public void setNilai2(double nilaiUjian2){
        this.nilaiUjian2  =nilaiUjian2 ;
    }
    public double getNilai2(){
        return  nilaiUjian2;
    }
         public void setTugas(double nilaiTugas){
        this.nilaiTugas  =nilaiTugas ;
    }
    public double getTugas(){
        return  nilaiTugas;
    }
    
    public double HitungNA(){
        return  nilaiakhir =0.35 * (nilaiUjian1)+ 0.40 *(nilaiUjian2)+0.25*(nilaiTugas);
    }
    public String isLulus(){
     String grade ="";
     
                if(nilaiakhir>60){
                    return grade = "LULUS";
             
                }else{
                   return grade = "Tidak Lulus";
                }
    } 
    public void cetak(){
        //System.out.println(HitungNA());
        
        System.out.println("Data Pelajar : "+getNama());
        System.out.println("NIP : "+getNip());
        System.out.println("Nilai 1 : "+getNilai1());
        System.out.println("Nilai 2 : "+getNilai2());
        System.out.println("Nilai tgs : "+getTugas());
        System.out.println("Nilai Akhir anda : "+HitungNA());
        System.out.println("Status : "+isLulus());
        
        
        
    }
   
}
