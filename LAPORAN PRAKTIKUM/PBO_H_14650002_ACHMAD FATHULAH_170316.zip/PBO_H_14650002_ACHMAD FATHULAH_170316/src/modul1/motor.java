/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package modul1;

/**
 *
 * @author Achmad Fathullah
 */
public class motor {
    
    private String NomorPlat,warna,manufaktur,kecepatan;
    private int perintah1,perintah2;
    
    public void setNomorPlat (String NomorPlat){
        this.NomorPlat = NomorPlat;
    }
    public String getNomorPlat(){
        return NomorPlat;
    }
    
    
    public void setWarna (String warna){
        this.warna = warna;
    }
    public String getWarna(){
        return warna;
    }
    
    
    public void setManufaktur (String manufaktur){
        this.manufaktur = manufaktur;
    }
    public String getManufaktur(){
        return manufaktur;
    }
    
    
    public void setKecepatan (String Kecepatan){
        this.kecepatan = kecepatan;
    }
    public String getKecepatan(){
        return kecepatan;
    }
    public void setPerintah1(int perintah1){
        this.perintah1 = perintah1;
    }
    public void setPerintah2(int perintah2){
        this.perintah2 = perintah2;
    }
    public String belok(){ 
        String belok = "";
        if(perintah1==1){
                    return belok = "KIRI";
             
                }else{
                   return belok = "KANAN";
                }
        
    }
    public String rem(){ 
        String belok = "";
        if(perintah2==1){
                    return belok = "ngerem";
             
                }else{
                   return belok = "lanjut";
                }
    
        
    }
    public void cetak(){
        System.out.println("Objek Mobil ");
        System.out.println("nomor plat : "+getNomorPlat());
        System.out.println("warna : "+getWarna());
        System.out.println("manufaktur : "+getManufaktur());
        System.out.println("kecepatan : "+getKecepatan());
        System.out.println("Belok ke : "+belok());
        System.out.println("Rem : "+rem());
       
    }
    public static void main(String[] args) {
        motor n = new motor();
        n.setNomorPlat("AI 6647 CH");
        n.setWarna("Biru");
        n.setManufaktur("Toyota");
        n.setKecepatan("30 km/jam");
        n.setPerintah1(1);
        n.setPerintah2(2);
        n.cetak();
        
    }
}
