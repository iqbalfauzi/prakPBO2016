/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan2;

/**
 *
 * @author LAB_TI
 */
import javax.swing.*;

public class KonfersiSuhu {

    private double celcius, farenheit, reamur;

    public double isiCelcius() {
        String isicelcius;
        isicelcius = JOptionPane.showInputDialog("Masukkan nilai celcius :");
        return celcius = Double.parseDouble(isicelcius);
    }

    public double fahrenheit() {

        double fahrenheit;
        return fahrenheit = 0.8 * (double) (celcius);
    }

    public double reamur() {
        double reamur;
        return reamur = 1.8 * (double) (celcius + 32);
    }

    public void cetak1() {
        JOptionPane.showMessageDialog(null, "Hasil konfersi 1:" + fahrenheit() + " Fahrenheit");
        System.out.println("Hasil konfersi 1 :" + fahrenheit()+ " Fahrenheit");
    }

    public void cetak2() {
        JOptionPane.showMessageDialog(null, "Hasil konfersi 2:" + reamur() + " Reamur");
        System.out.println("Hasil konfersi 2 :" + reamur()+ " Reamur");
    }
}
