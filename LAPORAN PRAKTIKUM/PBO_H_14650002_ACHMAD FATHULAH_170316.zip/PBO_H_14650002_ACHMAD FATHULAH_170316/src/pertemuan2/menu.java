/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan2;

import javax.swing.JOptionPane;

/**
 *
 * @author LAB_TI
 */
public class menu {

    public void pilihan() {
        Balok m = new Balok();
        KonfersiSuhu n = new KonfersiSuhu();
        for (;;) {
            JOptionPane.showMessageDialog(null, "Berikut adalah menu program pertemuan 2");

            String menu = JOptionPane.showInputDialog("Pilih menu program berikut :\n" + "1. Hitung keliling balok \n 2.Konfersi suhu1 \n 3.Konfersi suhu2 \n 4. Exit program");
            int a = Integer.parseInt(menu);
            if (a == 1) {
                m.isiLebar();
                m.isiPanjang();
                m.isiTinggi();
                m.cetak();
            } else if (a == 2) {
                n.isiCelcius();
                n.cetak1();
            } else if (a == 3) {
                n.isiCelcius();
                n.cetak2();
            } else if (a == 4) {
                break;
            }
        }
    }
}
