/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan2;

/**
 *
 * @author LAB_TI
 */
import javax.swing.*;

public class Balok {

    private double panjang, lebar, tinggi;

    public double isiPanjang() {
        String isipanjang;
        isipanjang = JOptionPane.showInputDialog("Masukkan nilai panjang :");
        return panjang = Double.parseDouble(isipanjang);

    }

    public double isiLebar() {
        String isilebar;
        isilebar = JOptionPane.showInputDialog("Masukkan nilai lebar :");
        return lebar = Double.parseDouble(isilebar);

    }

    public double isiTinggi() {
        String isitinggi;
        isitinggi = JOptionPane.showInputDialog("Masukkan nilai tinggi :");
        return tinggi = Double.parseDouble(isitinggi);

    }

    public double HitungKeliling() {
        double keliling;
        return keliling = 4 * (double) (panjang + lebar + tinggi);

    }

    public void cetak() {
        System.out.println("Hasil kelilingnya :" + HitungKeliling());
    }

}
